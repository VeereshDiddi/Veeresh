//
//  HomeData.m
//  QezyPlay
//
//  Created by ideabytes on 2016-10-22.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "HomeData.h"

NSMutableArray * packageList;
NSMutableArray * channelList;
NSMutableArray *channelsInfo;
NSMutableArray *bouquetChannelsInfo;
NSMutableArray *versioningInfo;
NSMutableArray *bouquetImages;
NSMutableArray *profilesInfo;
NSMutableArray *channelsInProfilesInfo;

