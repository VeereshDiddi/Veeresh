//
//  Constant.m
//  QezyPlay
//
//  Created by ideabytes on 2016-11-01.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constant.h"


NSString *channelBouquetsSC = @"http://104.196.99.177:6363/api/Bouquets";
NSString *channelsSC = @":http://104.196.99.177:6363/api/Channels";
NSString *profilesSC = @"http://104.196.99.177:6363/api/Profiles";
NSString *loginSC = @"http://104.196.99.177:6363/api/Customers/login";
NSString *customersSC = @"http://104.196.99.177:6363/api/Customers";
NSString *resetSC = @"http://104.196.99.177:6363/api/Customers/reset";
NSString *privacyPolicySC = @"http://104.196.99.177:6363/Privacy_Policy.htm";

NSMutableArray *defaulBouquets;
NSMutableArray *channelsInDefaultBouquets;

NSMutableArray *bouquetChannels;
NSMutableArray *channels;
NSMutableArray *versioning;
NSMutableArray *profiles;
NSMutableArray *channelsInProfiles;
NSMutableArray *subscriptionPlans;
NSMutableArray *subscriptionPlansBouquet;