//
//  ProfileCell.m
//  QezyPlay
//
//  Created by ideabytes on 2016-09-10.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import "ProfileCell.h"

@implementation ProfileCell

@end
