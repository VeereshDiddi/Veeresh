//
//  UserData.h
//  QezyPlay
//
//  Created by ideabytes on 2016-09-14.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import "Database.h"

#ifndef UserData_h
#define UserData_h

extern NSString * userID;
extern NSString * tokenID;

extern DataBase *deviceDB;


#endif /* UserData_h */
