//
//  ProfileCell.h
//  QezyPlay
//
//  Created by ideabytes on 2016-09-10.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileCell : UICollectionViewCell


@property (strong, nonatomic) IBOutlet UIImageView *imgCell;


@property (strong, nonatomic) IBOutlet UILabel *lblCell;


@end
