//
//  ProfileData.m
//  QezyPlay
//
//  Created by ideabytes on 2016-09-13.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import "ProfileData.h"

NSMutableArray *profileName;
NSMutableArray *profileImage;

NSMutableArray *profileIsLock;
NSMutableArray *profilePasswords;