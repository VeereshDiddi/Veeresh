//
//  WebViewController.h
//  QezyPlay
//
//  Created by MacBook Pro on 13/10/16.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController
{
    IBOutlet UIWebView *webViewObj;
}

@end
