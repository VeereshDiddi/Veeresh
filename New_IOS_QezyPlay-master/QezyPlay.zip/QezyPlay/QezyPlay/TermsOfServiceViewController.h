//
//  TermsOfServiceViewController.h
//  QezyPlay
//
//  Created by MacBook Pro on 10/11/16.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsOfServiceViewController : UIViewController
{
    IBOutlet UIWebView *webViewObj;
}
@end
