//
//  MediaPackageHeaderView.h
//  QezyPlay
//
//  Created by MacBook Pro on 20/10/16.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MediaPackageHeaderView : UICollectionReusableView
@property (weak, nonatomic) IBOutlet UILabel *commentLabel;

@end
