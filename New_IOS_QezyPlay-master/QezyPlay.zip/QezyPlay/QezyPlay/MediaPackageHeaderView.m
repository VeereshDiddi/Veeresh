//
//  MediaPackageHeaderView.m
//  QezyPlay
//
//  Created by MacBook Pro on 20/10/16.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import "MediaPackageHeaderView.h"

@implementation MediaPackageHeaderView

@end
