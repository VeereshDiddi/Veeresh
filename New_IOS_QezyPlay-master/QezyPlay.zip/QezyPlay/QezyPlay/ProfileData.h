//
//  ProfileData.h
//  QezyPlay
//
//  Created by ideabytes on 2016-09-13.
//  Copyright © 2016 ideabytes. All rights reserved.
//
#import <Foundation/Foundation.h>

#ifndef ProfileData_h
#define ProfileData_h

extern NSMutableArray *profileName;
extern NSMutableArray *profileImage;

extern NSMutableArray *profileIsLock;
extern NSMutableArray *profilePasswords;

#endif /* ProfileData_h */
