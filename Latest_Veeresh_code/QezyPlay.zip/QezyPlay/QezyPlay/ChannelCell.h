//
//  ChannelCell.h
//  QezyPlay
//
//  Created by ideabytes on 2016-08-24.
//  Copyright © 2016 ideabytes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChannelCell : UICollectionViewCell


@property (strong, nonatomic) IBOutlet UIImageView *imgCell;


@end
