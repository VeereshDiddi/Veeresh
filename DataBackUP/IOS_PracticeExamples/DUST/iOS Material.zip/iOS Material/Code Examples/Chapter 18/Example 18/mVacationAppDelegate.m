//
//  mVacationAppDelegate.m
//  mVacation
//
//  Created by Neal Goldstein on 6/29/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "mVacationAppDelegate.h"

@implementation mVacationAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
