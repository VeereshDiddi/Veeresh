//  © Copyright 2009 Neal Goldstein. All rights reserved.
//  For more information on this sample application or Objective-C For Dummies
//  Please visit www.nealgoldstein.com

#import "ATMTransactionDelegate.h"
#import "Budget.h"

@implementation ATMTransactionDelegate

- (void) spend: (Transaction *) aTransaction {
  
  [aTransaction.budget spendDollars: aTransaction.amount + 2.00];
}

- (void) dealloc {
  
  [super dealloc];
}

@end
