//
//  ViewController.h
//  NotificationCenter
//
//  Created by MacBook Pro on 24/06/16.
//  Copyright © 2016 MacBook Pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)addButtonClicked:(id)sender;

@end

