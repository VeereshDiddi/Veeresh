//
//  ViewController.m
//  NavigationControllerSample
//
//  Created by Mac on 14/05/16.
//  Copyright © 2016 Mac. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor colorWithRed:49.0/255.0 green:163.0/255.0 blue:243.0/255.0 alpha:0.0];
    self.title = @"First";
    
    UIButton *btn =[UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = CGRectMake(100, 300, 100, 100);
    [btn setTitle:@"Hello" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(testAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    UIButton *btn1 =[UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn1.frame = CGRectMake(100, 450, 100, 100);
    [btn1 setTitle:@"Test" forState:UIControlStateNormal];
    
    [btn1 setTitle:@"Close" forState:UIControlStateHighlighted];
    [btn1 addTarget:self action:@selector(testAction1) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];
    
}


- (void)testAction1{
    
    
}
- (void)testAction{
     self.view.backgroundColor = [UIColor yellowColor];
    //[self performSegueWithIdentifier:@"third" sender:nil];
    
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.view.backgroundColor = [UIColor redColor];
    
    NSLog(@"First ViewWillAppear");
    NSLog(@"First NAV::%@",self.navigationController.viewControllers);
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
