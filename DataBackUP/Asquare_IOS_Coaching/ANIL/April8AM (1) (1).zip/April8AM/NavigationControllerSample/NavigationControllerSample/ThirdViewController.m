//
//  ThirdViewController.m
//  NavigationControllerSample
//
//  Created by Mac on 14/05/16.
//  Copyright © 2016 Mac. All rights reserved.
//

#import "ThirdViewController.h"

@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Third";
    // Do any additional setup after loading the view.
    NSLog(@"Third ViewDidLoad");
     //NSLog(@"Third NAV::%@",self.navigationController.viewControllers);
    
    UIButton *btn =[UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = CGRectMake(100, 300, 100, 100);
    [btn setTitle:@"Hello" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(testAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}

- (void)testAction{

    
    if (self.navigationController.viewControllers.count>5) {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:5] animated:YES];
    }else{
        NSLog(@"Invalid Statement");
    }
    
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    NSLog(@"Third ViewWillAppear");
    NSLog(@"Third NAV::%@",self.navigationController.viewControllers);
    
    UIButton *btn =[UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = CGRectMake(100, 300, 100, 100);
    [btn setTitle:@"Hello" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(testAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];

}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    NSLog(@"Third viewDidAppear");
    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    NSLog(@"Third viewWillDisappear");
    self.view.backgroundColor = [UIColor greenColor];
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:YES];
    NSLog(@"Third viewDidDisappear");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
