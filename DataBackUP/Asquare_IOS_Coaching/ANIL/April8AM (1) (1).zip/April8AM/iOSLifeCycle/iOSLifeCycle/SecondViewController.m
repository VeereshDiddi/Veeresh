//
//  SecondViewController.m
//  iOSLifeCycle
//
//  Created by Mac on 12/05/16.
//  Copyright © 2016 Mac. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UILabel *lbl =[[UILabel alloc]initWithFrame:CGRectMake(10, 10, 300, 60)];
    lbl.numberOfLines =2;
    lbl.backgroundColor = [UIColor redColor];
    lbl.text=@"Welcome to AsquareWelcome to AsquareWelcome to AsquareWelcome to Asquare";
    
    [self.view addSubview:lbl];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
