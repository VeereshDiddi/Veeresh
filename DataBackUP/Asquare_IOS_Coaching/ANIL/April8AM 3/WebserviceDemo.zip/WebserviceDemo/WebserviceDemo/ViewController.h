//
//  ViewController.h
//  WebserviceDemo
//
//  Created by AsquareMobileTechnologies on 5/3/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong,nonatomic)NSMutableData *recievedData;
@end

