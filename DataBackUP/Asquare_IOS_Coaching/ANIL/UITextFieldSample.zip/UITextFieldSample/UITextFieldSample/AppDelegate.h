//
//  AppDelegate.h
//  UITextFieldSample
//
//  Created by AsquareMobileTechnologies on 5/21/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

