//
//  ViewController.m
//  FrameAndBounds
//
//  Created by AsquareMobileTechnologies on 5/19/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
   // self.btnSubmit.frame = self.view.bounds;
  //  NSLog(@"Frame and Bounds::%@ %@",NSStringFromCGRect(self.btnSubmit.frame),NSStringFromCGRect(self.btnSubmit.bounds));
    //self.btnSubmit
    UIView *vv1 =[[UIView alloc]initWithFrame:CGRectMake(100, 100, 50, 300)];
    
    vv1.backgroundColor = [UIColor greenColor];
    
    [self.view addSubview:vv1];
    
    UIView *vv =[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 100)];
    
    vv.backgroundColor = [UIColor redColor];
    
    vv.frame = CGRectMake((vv1.frame.size.width/2)-(vv.frame.size.width/2), (vv1.frame.size.height/2)-(vv.frame.size.height/2), vv.frame.size.width, vv.frame.size.height);
    [vv1 addSubview:vv];
    
    UIView *vv2 =[[UIView alloc]initWithFrame:vv.frame];
    
    vv2.backgroundColor = [UIColor yellowColor];
    
    [vv addSubview:vv2];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
