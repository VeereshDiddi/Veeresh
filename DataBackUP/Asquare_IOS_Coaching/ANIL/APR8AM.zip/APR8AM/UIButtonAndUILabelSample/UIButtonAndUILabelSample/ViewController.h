//
//  ViewController.h
//  UIButtonAndUILabelSample
//
//  Created by AsquareMobileTechnologies on 5/17/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

