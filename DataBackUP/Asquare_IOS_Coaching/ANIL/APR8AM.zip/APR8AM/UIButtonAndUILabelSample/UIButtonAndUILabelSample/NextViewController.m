//
//  NextViewController.m
//  UIButtonAndUILabelSample
//
//  Created by AsquareMobileTechnologies on 5/17/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import "NextViewController.h"
#import "ViewController.h"

@interface NextViewController ()

@end

@implementation NextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    ViewController *vv =[[ViewController alloc]init];
    vv.lbl1
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
