//
//  ViewController.m
//  UIButtonAndUILabelSample
//
//  Created by AsquareMobileTechnologies on 5/17/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    i =0;
    lbl.text = @"Hello World";
    self.lbl1.text = @"Asqure Mobile";
    
    UILabel *lbl3 = [[UILabel alloc]initWithFrame:CGRectMake(100, 100, 200, 30)];
    
    lbl3.text = @"Tech";
    lbl3.textAlignment = NSTextAlignmentRight;
    lbl3.textColor = [UIColor redColor];
    lbl3.font = [UIFont boldSystemFontOfSize:12];
    lbl3.backgroundColor = [UIColor greenColor];
    
    [self.view addSubview:lbl3];
    
    NSLog(@"SubViews::%@",[UIFont familyNames]);
    [self.lbl1 removeFromSuperview];
    
    UIButton *btn =[UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    btn.frame =CGRectMake(10, 300, 100, 40);
    [btn setTitle:@"Hello" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(testMethod:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    UISwitch *sc = [[UISwitch alloc]initWithFrame:CGRectMake(30, 20, 100, 30)];
    [sc addTarget:self action:@selector(swAction:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:sc];
    
    
    
}

- (void)swAction:(UISwitch *)obj{

    
    if (obj.on) {
        self.view.backgroundColor = [UIColor greenColor];
    }else{
        self.view.backgroundColor = [UIColor grayColor];
    }
}
- (void)testMethod:(UIButton *)myBtn{
    
    //[self.view setBackgroundColor:[UIColor redColor]];
    
    i++;
    self.view.backgroundColor = [UIColor colorWithRed:i*0.7 green:i*0.3 blue:i*0.5 alpha:1];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)submitAction:(UIButton *)sender {
    
    NSString *str =@"";
    if (i==0) {
        str =@"Save";
  
    }else if(i==1){
        str =@"Asqure";
   
    }else if(i==2){
        str =@"Mobile";
  
    }
    [sender setTitle:str forState:UIControlStateHighlighted];
    i++;
}

- (IBAction)actionData:(id)sender {

    
    for (id obj in self.view.subviews) {
        
        if ([obj isKindOfClass:[UILabel class]]) {
            [obj removeFromSuperview];
        }
        
    }
    //UIButton *bb = (UIButton *)sender;
    
    
    
}
@end
