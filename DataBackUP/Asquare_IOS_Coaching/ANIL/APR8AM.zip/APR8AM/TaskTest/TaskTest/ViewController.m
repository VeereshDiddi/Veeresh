//
//  ViewController.m
//  TaskTest
//
//  Created by AsquareMobileTechnologies on 5/19/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    i=0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)submitAction:(UIButton *)sender {
    
    if ([sender.currentTitle isEqualToString:@"Submit"]) {
        self.clearBtn.hidden = NO;
        int val = sender.frame.origin.y+sender.frame.size.height+10;
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(100,val+(i*32) , 100, 30)];
        
        lbl.backgroundColor = [UIColor redColor];
        i++;
        lbl.text = [NSString stringWithFormat:@"%d",i];
        [self.view addSubview:lbl];
       
    }else{
    
        
        for (id obj in self.view.subviews) {
            if ([obj isKindOfClass:[UILabel class]]) {
                [obj removeFromSuperview];
            }
        }
        i=0;
       // sender.hidden = YES;
        self.clearBtn.hidden = YES;
    }
    
    
}
@end
