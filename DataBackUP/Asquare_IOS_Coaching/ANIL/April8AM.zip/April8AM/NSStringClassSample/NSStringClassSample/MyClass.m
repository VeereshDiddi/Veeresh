//
//  MyClass.m
//  NSStringClassSample
//
//  Created by AsquareMobileTechnologies on 4/30/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import "MyClass.h"

@implementation MyClass
+ (int)myFuncWithparameterA:(int)a Bparam:(int)bbb{


    
    NSLog(@"Value is::%d %d %d",a,bbb,a+bbb);
    return a+bbb;
}
@end
