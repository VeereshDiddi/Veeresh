//
//  MyClass.h
//  NSStringClassSample
//
//  Created by AsquareMobileTechnologies on 4/30/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyClass : NSObject

@property(nonatomic,assign)int value;
+ (int)myFuncWithparameterA:(int)a Bparam:(int)bbb;
@end
