//
//  Student123.h
//  SampleObjectiveC
//
//  Created by AsquareMobileTechnologies on 4/29/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import "Student.h"

@interface Student123 : Student

@property(nonatomic,assign)int english;

- (void)myProperties;
+(void)myMethod;
@end
