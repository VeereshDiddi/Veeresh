//
//  ClassA.h
//  SampleObjectiveC
//
//  Created by AsquareMobileTechnologies on 4/28/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ClassA : NSObject
@property(nonatomic,assign)int value;
@property(nonatomic,assign)int value1;
+ (void)addA;
- (void)addB;
- (void)multiplicationOfTwoNumbers;
@end
