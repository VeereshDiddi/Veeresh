//
//  ViewController.m
//  QezyTVChannelLogos
//
//  Created by MacBook Pro on 11/08/16.
//  Copyright © 2016 MacBook Pro. All rights reserved.
//

#import "ViewController.h"
#import "ChannelViewController.h"

@interface ViewController ()
@end

@implementation ViewController
int channelNotFound = 0;

UIImageView *imgView;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.channelLogo = [[NSMutableArray alloc] initWithObjects:@"Bbc.jpg", @"IndiaToday.jpg", @"Discovery.jpg", @"AppleTV.jpg", @"Gtv.png", @"History.jpg", @"Hometv.jpg", @"Lifetime.jpg", @"Mtv.png", @"Sony.png", @"Suntv.jpg", @"ZeeTV.jpg", nil];
    
    self.channelURL = [[NSMutableArray alloc] initWithObjects:@"www.bbc.com", @"www.indiatoday.com", @"www.discovery.com", @"www.appletv.com", @"www.gtv.com", @"www.history.com", @"www.hometv.com", @"www.lifetime.com", @"www.mtv.com", @"www.sony.com", @"www.suntv.com", @"zeetv.com", nil];
    
    UISearchBar *searchBar = [UISearchBar new];
    searchBar.delegate = self;
    searchBar.showsCancelButton = YES;
    self.navigationItem.titleView = searchBar;
    
    if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
        // iOS 7
        [self prefersStatusBarHidden];
        [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
    } else {
        // iOS 6
        [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
    }
}

// Add this Method
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

//viewWillAppear
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.collectionView reloadData];
}

#pragma mark - numberOfSectionsInCollectionView

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

#pragma mark - numberOfItemsInSection

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
//    return [channelLogo count];
    int rowCount;
    if(self.isFiltered)
        rowCount = (int)self.filteredTableData.count;
    else
        rowCount = (int)[self.channelLogo count];
    
    return rowCount;
}

#pragma mark - cellForItemAtIndexPath

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"collectionCell" forIndexPath:indexPath];
    
//    UIImageView *imgView = (UIImageView*)[cell viewWithTag:1];
    imgView = (UIImageView*)[cell viewWithTag:1];
    NSString *str1;
    
    if(self.isFiltered)
        str1 = [self.filteredTableData objectAtIndex:indexPath.row];
    else
        str1 = [self.channelLogo objectAtIndex:indexPath.row];
    
    
    imgView.image = [UIImage imageNamed:str1];
    [imgView.layer setBorderWidth: 1.0];
//  NSLog(@"%li", (long)indexPath.row);
    
    return cell;
}

#pragma mark - didSelectItemAtIndexPath

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    // TODO: Select Item
    if(self.isFiltered)
        self.nameSelected = [self.filteredTableData objectAtIndex:[indexPath row]];
    else
        self.nameSelected = [self.channelLogo objectAtIndex:[indexPath row]];

    NSLog(@"Name: %@ ...", self.nameSelected);
    
    [self performSegueWithIdentifier:@"channelView" sender:self];
}

#pragma mark - didDeselectItemAtIndexPath

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath {
    // TODO: Deselect item
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    for (int i = 0; i < [self.channelLogo count]; i++) {
        if ([self.nameSelected isEqualToString:[self.channelLogo objectAtIndex:i]]) {
            self.urlSelected = [NSMutableString stringWithFormat:@"%@", [self.channelURL objectAtIndex:i]];
        }
    }
    
    if ([[segue identifier]isEqualToString:@"channelView"]) {
        
        ChannelViewController *channelViewObj = [segue destinationViewController];
        channelViewObj.logoURL = self.urlSelected;
    }
}

#pragma mark - UICollectionViewFlowLayout

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat picDimension = self.view.frame.size.width / 4.0f;
    return CGSizeMake(picDimension, picDimension);
}

#pragma mark - insetForSectionAtIndex

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    CGFloat leftRightInset = self.view.frame.size.width / 14.0f;
    return UIEdgeInsetsMake(0, leftRightInset, 0, leftRightInset);
}


//*****************
// SEARCH BAR
//*****************

-(void)searchBar:(UISearchBar*)searchBar textDidChange:(NSString*)text
{
    //NSLog(@"searchBar ... text.length: %d", text.length);
    
    if(text.length == 0)
    {
        self.isFiltered = FALSE;
        [searchBar resignFirstResponder];
    }
    else
    {
        self.isFiltered = true;
        self.filteredTableData = [[NSMutableArray alloc] init];
        
        for (NSString* item in self.channelLogo)
        {
            //case insensative search - way cool
            if ([item rangeOfString:text options:NSCaseInsensitiveSearch].location != NSNotFound)
            {
                [self.filteredTableData addObject:item];
            }
            if ([item isEqualToString:@"Zeal.png"])//taratv-1.png & Zeal.png
            {
//                NSLog(@"Selected LOGO found.");
            }
            else
            {
//              NSLog(@"Selected LOGO not found.");
                channelNotFound++;
            }
        }
    }//end if-else
    
    //Channel Not Found.
    if (channelNotFound == [self.channelLogo count]) {
        NSLog(@"Selected LOGO not found.");
        NSLog(@"Item Not Found:%d", channelNotFound);
        channelNotFound = 0;
        
        //Download and save in App
        [self saveImagesInLocalDirectory];
        [self loadImage];
    }
    [self.collectionView reloadData];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    //User hit Search button on Keyboard
    [searchBar resignFirstResponder];
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    [searchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    searchBar.text=@"";
    
    [searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];
    
    self.isFiltered = FALSE;
    [self.collectionView reloadData];
}

//Download and save in App
-(void)saveImagesInLocalDirectory
{
    NSString * documentsDirectoryPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSLog(@"Directory Path:%@", documentsDirectoryPath);
    NSString *imgName = @"Zeal.png";
    NSString *imgURL = @"http://ideabytestraining.com/newqezyplay/wp-content/uploads/2016/06/Zeal.png";
//    NSString *imgName = @"taratv-1.png";
//    NSString *imgURL = @"http://ideabytestraining.com/newqezyplay/wp-content/uploads/2016/06/taratv-1.png";
    
    [self.channelLogo addObject:imgName];
    [self.channelURL addObject:imgURL];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *writablePath = [documentsDirectoryPath stringByAppendingPathComponent:imgName];
    
    if(![fileManager fileExistsAtPath:writablePath]){
        // file doesn't exist
        NSLog(@"file doesn't exist");
        //save Image From URL
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString: imgURL]];
        //NSLog(@"DATA:%@", data);
        
        NSError *error = nil;
        [data writeToFile:[documentsDirectoryPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", imgName]] options:NSAtomicWrite error:&error];
        
        if (error) {
            NSLog(@"Error Writing File : %@",error);
        }else{
            NSLog(@"Image %@ Saved SuccessFully",imgName);
        }
    }
    else{
        // file exist
        NSLog(@"file exist");
    }
}

- (void)loadImage {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString* path = [documentsDirectory stringByAppendingPathComponent:@"Zeal.png" ];
    //taratv-1.png  &  Zeal.png
//    self.imageView.image = [UIImage imageWithContentsOfFile:path];
    
//    UIImage *img = [UIImage imageWithContentsOfFile:path];
    imgView.image = [UIImage imageNamed:path];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
