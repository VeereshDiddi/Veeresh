//
//  ViewController.h
//  QezyTVChannelLogos
//
//  Created by MacBook Pro on 11/08/16.
//  Copyright © 2016 MacBook Pro. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController<UICollectionViewDataSource, UICollectionViewDelegate, UISearchBarDelegate>
{
       NSInteger selectedRow;
}

@property (strong, nonatomic)  NSMutableArray *channelLogo;

@property (strong, nonatomic) NSMutableArray *channelURL;

@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (strong, nonatomic) NSMutableString *nameSelected;
@property(strong, nonatomic) NSMutableString *urlSelected;


//SEARCH BAR
@property (strong, nonatomic) NSMutableArray* filteredTableData;
@property (nonatomic, assign) bool isFiltered;


@end

